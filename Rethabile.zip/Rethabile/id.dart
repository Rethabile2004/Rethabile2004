//Purpose: To Validate the ID nymber of the user.
import 'dart:io';

void main() {
  stdout.write(' Enter a 13 Digit SA ID Number : ');
  String idNum = stdin.readLineSync()!;
  String dob = getDateOfBirth(idNum);
  String gender = getGender(idNum);
  String citizen = getCitizenship(idNum);

  print('''----------------------------
  ID Number     : $idNum
  Date of Birth : $dob
  Gender        : $gender
  Citizenship   : $citizen

 ----------------------------
 ''');
} //end method

//--------------------------------------------------------------------------//
//------------------------getGender method----------------------------------//
//--------------------------------------------------------------------------//
String getGender(String id) {
  //gender variable to hold the gender
  String gender = "";
  //decision making to test the length of the id parameter before assigning it a value
  String g = id.length == 13 ? id.substring(6, 7) : "";
  //decision making to test the gender based on the id entered as a parameter
  if (id.length == 13) {
    if (g == "5" || g == "6" || g == "7" || g == "8" || g == "9") {
      gender = "Male";
    } else {
      gender = "Female";
    } //end else
  } else {
    gender = "Invalid IDNum";
  }
  return gender;
} //end method

//--------------------------------------------------------------------------//
//------------------------getCitizanship method-----------------------------//
//--------------------------------------------------------------------------//
String getCitizenship(String id) {
  //citizenship variable will hold the citizenship
  String citizenship = "";
  //decision making to test the length of the id parameter before assigning it a value
  String c = id.length == 13 ? id.substring(10, 11) : "";
  //decision making to test the citizenship based on the id entered
  if (id.length == 13) {
    if (c == "0") {
      citizenship = "SA Citizen";
    } else if (c == "1") {
      citizenship = "Permanent Resident";
    } else {
      citizenship = "Unknown";
    } //end else
  } else {
    citizenship = "Invalid IDNum";
  } //end else

  return citizenship;
} //end method

//--------------------------------------------------------------------------//
//------------------------getDateOfBirth method-----------------------------//
//--------------------------------------------------------------------------//
String getDateOfBirth(String id) {
  //decion making based on the parameter String id
  return id.length == 13 ? id.substring(0, 7) : "Invalid IDNum";
} //end method
