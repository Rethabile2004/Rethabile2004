﻿//
// Programmer       : Rethabile Eric Siase
// Purpose          : The purpose of this program is manage Employee and Student information
// Contributors     : 6
//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S1P1
{
    public class Employee : Person,ICloneable
    {
        public string CompanyName
        {
            //
            //Method Name : property string CompanyName
            //Purpose : Automatic public property to give access to corresponding compiler generated field 
            //Re-use : none
            //Input Parameter : string value
            //                  - new value for corresponding compiler generated field
            //Output Type : string
            //              - value stored in the corresponding compiler generated field
            //
            get; set;
        }//end property
        public Employee(string id, string firstName, string lastName, string companyName) : base(id, firstName, lastName)
        {
            //
            //Name : Person(string id, string firstName, string lastName, string companyName)
            //Purpose : Overloaded constructor used to update properties
            //Re-use : None
            //Input Parameters : string id
            //                  - new value for the ID property
            //                  string firstName
            //                  - new value for the FirstName property
            //                  string lastName
            //                 - new value for the LastName property
            //                  string companyName
            //                  - new value for the CompanyName property
            //Output Type      : none
            //
            this.CompanyName = companyName;
        } // end method
        public override string GetInfo()
        {
            //
            //Method Name : string GetInfo()
            //Purpose : To display the Employee information
            //Re-use : GetInfo()
            //Input Parameter : none
            //Output Type : string
            //              - the Employee information
            //
            return base.GetInfo()+"\nCompany: "+CompanyName;
        } // end method
        public override string ToString()
        {
            //
            //Method Name : string ToString()
            //Purpose : To display the Employee information
            //Re-use : GetInfo()
            //Input Parameter : none
            //Output Type : string
            //              - the Employee information
            //
            return GetInfo();
        } // end method
        public object Clone()
        {
            //
            //Method Name : object Clone()
            //Purpose : To create a perfect copy of an Employee object
            //Re-use : none()
            //Input Parameter : none
            //Output Type : object
            //              - the clone of Employee object
            //
            Employee newEmp = new Employee(this.ID, this.FirstName, this.LastName, this.CompanyName)
            {
                HomeAddress = new Address
                {
                    City = this.HomeAddress.City,
                    Street = this.HomeAddress.Street
                } // end initializer
            };
            return newEmp;
        } // end method
    } // end class
} //end namespace
